<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/conta','ContaController@index')->name('conta');
Route::get('/create-conta','ContaController@create')->name('create-conta');
Route::post('/store-conta','ContaController@store')->name('store-conta');
Route::get('/edit-conta/{id}','ContaController@edit')->name('edit-conta');
Route::post('/update-conta/{id}','ContaController@update')->name('update-conta');
Route::get('/confirm-delete/{id}', 'ContaController@confirmDelete')->name('confirm-delete');
Route::get('/delete-conta/{id}','ContaController@destroy')->name('delete-conta');

Route::get('/form-saque/{id}','ContaController@formSaque')->name('form-saque');
Route::post('/saque/{id}','ContaController@sacar')->name('saque');

Route::get('/form-deposito/{id}','ContaController@formDeposito')->name('form-deposito');
Route::post('/deposito/{id}','ContaController@depositar')->name('deposito');

Route::get('/form-transferencia', 'ContaController@formTransferencia')->name('form-transferencia');
Route::post('/transferencia','ContaController@transferencia')->name('transferencia');


