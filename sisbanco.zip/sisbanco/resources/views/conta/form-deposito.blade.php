@extends('layouts.index')

@section('content')

<div class="card">
            <div class="card-header">
                Contas
               
            </div>
            <div class="card-body">
                <form action="{{ route('deposito', $conta->id) }}" class="form" method="post">
                @csrf

                <div class="form-group">
                    <label for="">Valor do deposito:</label>
                    <input class="form-control" type="number" name="valor_deposito">
                </div>

                <button class="btn btn-primary" type="submit">Depositar</button>
                <a href="{{ route('conta') }}" class="btn btn-secondary">Voltar</a>

                </form>
            </div>
        </div>
        
@endsection

