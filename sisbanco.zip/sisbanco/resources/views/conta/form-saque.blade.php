@extends('layouts.index')

@section('content')

<div class="card">
            <div class="card-header">
                Contas
               
            </div>
            <div class="card-body">
                <form action="{{ route('saque', $conta->id) }}" class="form" method="post">
                @csrf

                <div class="form-group">
                    <label for="">Valor do saque:</label>
                    <input class="form-control" type="number" name="valor_saque">
                </div>

                <button class="btn btn-primary" type="submit">Sacar</button>
                <a href="{{ route('conta') }}" class="btn btn-secondary">Voltar</a>

                </form>
            </div>
        </div>
        
@endsection

