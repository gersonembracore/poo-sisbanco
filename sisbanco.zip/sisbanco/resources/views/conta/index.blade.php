@extends('layouts.index')

@section('content')

<div class="card shadow mt-4">
            <div class="card-body">
            <br>
                <table class="table table-striped" id="myTable">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Agência</th>
                            <th>Tipo</th>
                            <th>Número</th>
                            <th>Nome</th>
                            <th>Saldo</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($contas as $conta)
                            <tr>
                                <td>{{ $conta->id }}</td>
                                <td class="text-right">{{ $conta->agencia }}</td>
                                <td>{{ $conta->tipo }}</td>
                                <td class="text-right">{{ $conta->numero }}</td>
                                <td>{{ $conta->nome_cliente }}</td>
                                <td class="text-right">{{ $conta->saldo }}</td>
                                <td>
                                    <a href="{{ route('edit-conta',$conta->id) }}" class="btn btn-primary"><i class="fa fa-edit"></i></a>
                                    <a href="{{ route('confirm-delete',$conta->id) }}" class="btn btn-danger"><i class="fa fa-trash"></i></a>
                                    <a href="{{ route('form-deposito',$conta->id) }}" class="btn btn-info"><i class="fa fa-download"></i></a>
                                    <a href="{{ route('form-saque',$conta->id) }}" class="btn btn-warning"><i class="fa fa-upload"></i></a>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
 </div>
        
@endsection

