@extends('layouts.index')

@section('content')
    <div class="card">
        <div class="card-header">Resultado da pesquisa</div>
        <div class="card-body">
            {{ $conta[0]->id }}
        </div>
    </div>
@endsection