@extends('layouts.index')

@section('content')
    <div class="card shadow mt-4">
        <div class="card-header bg-danger text-light">Deseja realmente excluir?</div>
        <div class="card-body">
            <h4>Informações da conta</h4>
            Numero: {{ $conta->numero }} <br>
            Agencia: {{ $conta->agencia }} <br>
            Nome do cliente: {{ $conta->nome_cliente }} <br>
            Saldo: {{ $conta->saldo }}
        </div>
        <div class="card-footer">
            <a class="btn btn-success" href="{{ route('delete-conta', $conta->id )}}"> <i class="fa fa-check"></i> Confirmar</a>
        </div>
    </div>
@endsection