@extends('layouts.index')

@section('content')

    <div class="container">
        <div class="card">
            <div class="card-header">Cadastrar Conta</div>

            <div class="card-body">
                <form action="{{ route('store-conta') }}" method="post" class="form">
                    @csrf
                    <div class="form-group">
                        <label for="">Agência</label>
                        <input type="text" name="agencia" class="form-control">
                    </div>


                    <div class="form-group">
                        <label for="">Tipo</label>
                        <select name="tipo" id="" class="form-group">
                            <option value="corrente">Conta Corrente</option>
                            <option value="poupanca">Conta Poupança</option>
                        </select>
                    </div>


                    <div class="form-group">
                        <label for="">Número</label>
                        <input type="text" name="numero" class="form-control">
                    </div>


                    <div class="form-group">
                        <label for="">Nome</label>
                        <input type="text" name="nome" class="form-control">
                    </div>


                    <div class="form-group">
                        <label for="">Saldo</label>
                        <input type="text" name="saldo" class="form-control">
                    </div>

                    <button class="btn btn-success" type="submit">Gravar</button>
                    <a href="{{ route('conta') }}" class="btn btn-secondary">Voltar</a>
                </form>
            </div>
        </div>
    </div>  
        
    @endsection