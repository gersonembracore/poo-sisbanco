@extends('layouts.index')

@section('content')

<div class="card">
            <div class="card-header">
                Transferência
            </div>
            <div class="card-body">
                <form action="{{ route('transferencia') }}" class="form" method="post">
                    @csrf
                    <div class="form-group">
                        <label for="">Conta de origem:</label>
                        <select name="conta_origem" id="" class="form-control"> 
                        @foreach($contas as $conta) 
                            <option value="{{$conta->id}}">{{ $conta->numero }} - {{ $conta->nome_cliente }} - Saldo Atual: {{ $conta->saldo }}</option>
                        @endforeach
                        </select>
                    </div>


                    <div class="form-group">
                        <label for="">Conta de destino</label>
                        <select name="conta_destino" id="" class="form-control"> 
                        @foreach($contas as $conta) 
                            <option value="{{$conta->id}}">{{ $conta->numero }} - {{ $conta->nome_cliente }} - Saldo Atual: {{ $conta->saldo }}</option>
                        @endforeach
                        </select>
                    </div>


                    <div class="form-group">
                        <label for="">Valor do saque:</label>
                        <input class="form-control" type="number" name="valor_transferencia">
                    </div>

                    <button class="btn btn-primary" type="submit">Transferir</button>
                    <a href="{{ route('conta') }}" class="btn btn-secondary">Voltar</a>

                </form>
            </div>
        </div>
        
@endsection

