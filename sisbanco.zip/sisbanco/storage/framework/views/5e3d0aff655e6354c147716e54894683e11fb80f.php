<?php $__env->startSection('content'); ?>

<div class="card shadow mt-4">
            <div class="card-body">
            <br>
                <table class="table table-striped" id="myTable">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Agência</th>
                            <th>Tipo</th>
                            <th>Número</th>
                            <th>Nome</th>
                            <th>Saldo</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $contas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($conta->id); ?></td>
                                <td class="text-right"><?php echo e($conta->agencia); ?></td>
                                <td><?php echo e($conta->tipo); ?></td>
                                <td class="text-right"><?php echo e($conta->numero); ?></td>
                                <td><?php echo e($conta->nome_cliente); ?></td>
                                <td class="text-right"><?php echo e($conta->saldo); ?></td>
                                <td>
                                    <a href="<?php echo e(route('edit-conta',$conta->id)); ?>" class="btn btn-primary"><i class="fa fa-edit"></i></a>
                                    <a href="<?php echo e(route('confirm-delete',$conta->id)); ?>" class="btn btn-danger"><i class="fa fa-trash"></i></a>
                                    <a href="<?php echo e(route('form-deposito',$conta->id)); ?>" class="btn btn-info"><i class="fa fa-download"></i></a>
                                    <a href="<?php echo e(route('form-saque',$conta->id)); ?>" class="btn btn-warning"><i class="fa fa-upload"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
 </div>
        
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>