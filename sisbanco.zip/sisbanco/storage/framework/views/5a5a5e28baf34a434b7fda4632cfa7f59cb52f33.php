<?php $__env->startSection('content'); ?>
    <div class="card shadow mt-4">
        <div class="card-header bg-danger text-light">Deseja realmente excluir?</div>
        <div class="card-body">
            <h4>Informações da conta</h4>
            Numero: <?php echo e($conta->numero); ?> <br>
            Agencia: <?php echo e($conta->agencia); ?> <br>
            Nome do cliente: <?php echo e($conta->nome_cliente); ?> <br>
            Saldo: <?php echo e($conta->saldo); ?>

        </div>
        <div class="card-footer">
            <a class="btn btn-success" href="<?php echo e(route('delete-conta', $conta->id )); ?>"> <i class="fa fa-check"></i> Confirmar</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>