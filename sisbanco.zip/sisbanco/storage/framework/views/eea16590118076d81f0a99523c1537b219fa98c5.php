<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="card">
            <div class="card-header bg-primary text-light">Atualizar Conta - <?php echo e($conta->nome_cliente); ?> - <?php echo e($conta->numero); ?> </div>

            <div class="card-body">
                <form action="<?php echo e(route('update-conta',$conta->id)); ?>" method="post" class="form">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="">Agência</label>
                        <input type="text" name="agencia" class="form-control" value="<?php echo e($conta->agencia); ?>">
                    </div>


                    <div class="form-group">
                        <label for="">Tipo</label>
                        <select name="tipo" id="" class="form-control">
                            <option value="<?php echo e($conta->tipo); ?>" > Tipo Atual: <?php echo e($conta->tipo); ?> </option>
                            <option value="corrente">Conta Corrente</option>
                            <option value="poupanca">Conta Poupança</option>
                        </select>
                    </div>


                    <div class="form-group">
                        <label for="">Número</label>
                        <input type="text" name="numero" class="form-control" value="<?php echo e($conta->numero); ?>">
                    </div>


                    <div class="form-group">
                        <label for="">Nome</label>
                        <input type="text" name="nome" class="form-control" value="<?php echo e($conta->nome_cliente); ?>">
                    </div>


                    <div class="form-group">
                        <label for="">Saldo</label>
                        <input type="text" name="saldo" class="form-control" value="<?php echo e($conta->saldo); ?>">
                    </div>

                    <button class="btn btn-success" type="submit">Gravar</button>
                    <a href="<?php echo e(route('conta')); ?>" class="btn btn-secondary">Voltar</a>
                </form>
            </div>
        </div>
    </div> 
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>