<?php $__env->startSection('content'); ?>

<div class="card">
            <div class="card-header">
                Contas
               
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('saque', $conta->id)); ?>" class="form" method="post">
                <?php echo csrf_field(); ?>

                <div class="form-group">
                    <label for="">Valor do saque:</label>
                    <input class="form-control" type="number" name="valor_saque">
                </div>

                <button class="btn btn-primary" type="submit">Sacar</button>
                <a href="<?php echo e(route('conta')); ?>" class="btn btn-secondary">Voltar</a>

                </form>
            </div>
        </div>
        
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>