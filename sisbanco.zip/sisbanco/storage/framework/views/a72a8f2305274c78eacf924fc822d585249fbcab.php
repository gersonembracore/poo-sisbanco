<?php $__env->startSection('content'); ?>

<div class="card">
            <div class="card-header">
                Transferência
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('transferencia')); ?>" class="form" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="">Conta de origem:</label>
                        <select name="conta_origem" id="" class="form-control"> 
                        <?php $__currentLoopData = $contas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                            <option value="<?php echo e($conta->id); ?>"><?php echo e($conta->numero); ?> - <?php echo e($conta->nome_cliente); ?> - Saldo Atual: <?php echo e($conta->saldo); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>


                    <div class="form-group">
                        <label for="">Conta de destino</label>
                        <select name="conta_destino" id="" class="form-control"> 
                        <?php $__currentLoopData = $contas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                            <option value="<?php echo e($conta->id); ?>"><?php echo e($conta->numero); ?> - <?php echo e($conta->nome_cliente); ?> - Saldo Atual: <?php echo e($conta->saldo); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>


                    <div class="form-group">
                        <label for="">Valor do saque:</label>
                        <input class="form-control" type="number" name="valor_transferencia">
                    </div>

                    <button class="btn btn-primary" type="submit">Transferir</button>
                    <a href="<?php echo e(route('conta')); ?>" class="btn btn-secondary">Voltar</a>

                </form>
            </div>
        </div>
        
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>