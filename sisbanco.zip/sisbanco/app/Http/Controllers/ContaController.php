<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Conta;

class ContaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $contas = Conta::all();
        return view('conta.index',compact('contas'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('conta.create-conta');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $create_conta = Conta::create([
            'agencia'       => $request['agencia'],
            'tipo'          => $request['tipo'],
            'numero'        => $request['numero'],
            'nome_cliente'  => $request['nome'],
            'saldo'         => $request['saldo']
        ]);
        
        if($create_conta) 
        {
            return redirect()->route('conta');
        } else 
        {
            return redirect()->route('create-conta');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $conta = Conta::findOrFail($id);
        return view('conta.edit-conta', compact('conta'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $conta = Conta::findOrFail($id);
        
        $update_conta = $conta->update([
            'agencia'       => $request['agencia'],
            'tipo'          => $request['tipo'],
            'numero'        => $request['numero'],
            'nome_cliente'  => $request['nome'],
            'saldo'         => $request['saldo']
        ]);

        if($update_conta) 
        {
            return redirect()->route('conta');
        } else {
            return redirect()->route('edit-conta',$conta->id);
        }
    }

    public function confirmDelete($id)
    {   
        $conta = Conta::findOrFail($id);
        return view('conta.confirm-delete', compact('conta'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $conta = Conta::findOrFail($id);
        $delete_conta = $conta->delete();

        if($delete_conta) 
        {
            $alerta = [
                'message'       =>  'Conta deletada com sucesso!',
                'alert-type'    =>  'success'
            ];
            
            return redirect()->route('conta')->with($alerta);
        } 
    }

    public function formSaque($id) 
    {
        $conta = Conta::findOrFail($id);
        return view('conta.form-saque',compact('conta'));   
    }

    public function sacar(Request $request, $id) 
    {
        $conta = Conta::findOrFail($id);
        $saldo_atual = $conta->saldo;
        $valor_saque = $request['valor_saque'];

        if ($saldo_atual >= $valor_saque) {

            $novo_saldo = $saldo_atual - $valor_saque;
            $saque = $conta->update([
                'saldo' => $novo_saldo
            ]);
    
            if($saque)
            {
                return redirect()->route('conta');
            }
        } else {
            return view('conta.form-saque',compact('conta'));
        }

    }




    public function formDeposito($id) 
    {
        $conta = Conta::findOrFail($id);
        return view('conta.form-deposito',compact('conta'));   
    }

    public function depositar(Request $request, $id) 
    {
        $conta = Conta::findOrFail($id);
        $saldo_atual = $conta->saldo;
        $valor_deposito = $request['valor_deposito'];
        $novo_saldo = $saldo_atual + $valor_deposito;
        $deposito = $conta->update([
            'saldo' => $novo_saldo
        ]);

        if($deposito)
        {
            return redirect()->route('conta');
        }
    }


    public function formTransferencia()
    {
        $contas = Conta::all();
        return view('conta.form-transferencia',compact('contas'));
    }


    public function transferencia(Request $request) 
    {
        $conta_origem = Conta::findOrFail($request['conta_origem']);
        $conta_destino = Conta::findOrFail($request['conta_destino']);
        $valor_transferencia = $request['valor_transferencia'];
        
        if ($request['valor_transferencia'] > $conta_origem->saldo) {
            
            $alerta = [
                'message'       => 'Saldo insuficiênte',
                'alert-type'    => 'error'
            ];
            return redirect()->route('form-transferencia')->with($alerta);

        } else {

            $transferir = $conta_origem->update([
                'saldo' => $conta_origem->saldo - $valor_transferencia 
            ]);
          
            $receber = $conta_destino->update([
                'saldo' => $conta_destino->saldo + $valor_transferencia 
            ]);
    
            

            if ($transferir && $receber) {
                $alerta = [
                    'message'       => 'Transferência realizada!',
                    'alert-type'    => 'success'
                ];
                
                return redirect()->route('conta')->with($alerta);
            }      
        }      
    }


}
