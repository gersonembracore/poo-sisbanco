<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Conta extends Model
{
    protected $table = 'conta' ;
    protected $fillable = [
        'agencia',
        'tipo',
        'numero',
        'nome_cliente',
        'saldo'
    ];
}
